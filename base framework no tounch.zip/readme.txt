WASD - move forward, left, backward, right
Arrow keys - pitch, yaw camera
E - exit tent
1,2 - toggle front face culling
3,4 - toggle wireframe mode

-Skyplane
-Sprite Animation (Fire)
-Multitexturing (Tree, Water)
-Moving Texture (Water)
-Terrain
-Dog will follow you
-Walk into tent to lie down, press E to exit
-Random placement of trees
-Smooth Terrain collision

-point light from campfire
-smoke particles (rise and shrink)
-spark particles fly out from fire and fall
-billboard effect on dog
-fog 
-shadow from light of campfire from and on all objs in range
-shadow on billboarded dog
-16x antialiasing